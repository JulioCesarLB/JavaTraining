package repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import connectionFactory.*;
import model.*;

public class UsuarioDAO {
	private Connection conexao;
	
	public UsuarioDAO() {
		this.conexao= new ConnectionFactory().getConnection();
	}
	
	public void insert(Usuario usuario) throws SQLException{
		String sql ="insert into usuarios(id, nome, email, telefone, data) values (?,?,?,?,?)";
		PreparedStatement stmt = conexao.prepareStatement(sql);
		
		stmt.setLong(1, usuario.getId());
		stmt.setString(2,usuario.getNome());
		stmt.setString(3, usuario.getEmail());
		stmt.setInt(4, usuario.getTelefone());
		stmt.setDate(5, usuario.getData());
		
		stmt.execute();
		stmt.close();
	}
	public List<Usuario> select() throws SQLException{
		List<Usuario> usuarios = new ArrayList<Usuario>();
		String sql = "Select * from usuarios";
		PreparedStatement stmt = conexao.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			Usuario usuario = new Usuario();
			usuario.setId(rs.getLong("id"));
			usuario.setEmail(rs.getString("email"));
			usuario.setNome(rs.getString("nome"));
			usuario.setTelefone(rs.getInt("telefone"));
			usuario.setData(rs.getDate("data"));
			
			usuarios.add(usuario);
		}
		rs.close();
		stmt.close();
		return usuarios;
	}
	
	public List<Usuario> selectById(long ID) throws SQLException{
		List<Usuario> usuarios = new ArrayList<Usuario>();
		String sql = "Select * from usuarios where id=?";
		PreparedStatement stmt = conexao.prepareStatement(sql);
		
		stmt.setLong(1, ID);
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			Usuario usuario = new Usuario();
			usuario.setId(rs.getLong("id"));
			usuario.setEmail(rs.getString("email"));
			usuario.setNome(rs.getString("nome"));
			usuario.setTelefone(rs.getInt("telefone"));
			usuario.setData(rs.getDate("data"));
			
			usuarios.add(usuario);
		}
		rs.close();
		stmt.close();
		return usuarios;
	}
	
	public void update(Usuario usuario) throws SQLException{
		String sql = "update usuarios set nome=?, email=?, telefone=? where id=?";
		String nome= usuario.getNome(), email=usuario.getEmail();
		int telefone = usuario.getTelefone();
		
		PreparedStatement stmt = conexao.prepareStatement(sql);
		
		if(JOptionPane.showInputDialog("Dejesa modificar o nome??").charAt(0)=='s' ) {
			nome = JOptionPane.showInputDialog(null,"Digite o novo nome: ");
		}
		if(JOptionPane.showInputDialog("Dejesa modificar o email??").charAt(0)=='s' ) {
			email = JOptionPane.showInputDialog(null,"Digite o novo email: ");
		}
		if(JOptionPane.showInputDialog("Dejesa modificar o telefone??").charAt(0)=='s' ) {
			telefone = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite o novo telefone: "));
		}
		stmt.setString(1,nome);
		stmt.setString(2,email);
		stmt.setInt(3,telefone);
		stmt.setLong(4, usuario.getId());
		
		stmt.execute();
		stmt.close();
		
	}
	public void  delete(Long id) throws SQLException {
		String sql = "delete from usuarios where id=?";
		PreparedStatement stmt = conexao.prepareStatement(sql);
		
		stmt.setLong(1,id);
		
		stmt.execute();
		stmt.close();
	}
	
	
	
	
	public void create() throws SQLException{
		String sql = "CREATE TABLE usuarios (id int NOT NULL,"
				+ "nome varchar(45) NOT NULL,"
				+ "email varchar(45) NOT NULL,"
				+ "telefone int NOT NULL,"
				+ "data date NOT NULL,"
				+ "PRIMARY KEY (id))";
		Statement stmt = conexao.createStatement();
		stmt.executeUpdate(sql);
		
	}
}
