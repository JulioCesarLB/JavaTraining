package testes;

import java.sql.Date;
import java.sql.SQLException;
import java.util.*;

import model.Usuario;
import repository.UsuarioDAO;

public class Teste {
	public static void main(String Args[]) {
		
		Usuario julio = new Usuario();
		julio.setId(1);
		julio.setNome("Delfino");
		julio.setEmail("email");
		julio.setTelefone(900000000);
		
		
		Calendar hoje = Calendar.getInstance();
		Date data = new Date(hoje.getTimeInMillis());
		julio.setData(data);

		/*
		try {
			dao.insert(julio);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		UsuarioDAO dao = new UsuarioDAO();
		List<Usuario> lista = new ArrayList<Usuario>();
		try {
			lista = dao.select();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(Usuario user:lista) {
			System.out.println("Nome: "+user.getNome()+" | Email: "+user.getEmail());
		}
		
	
		try {
			lista = dao.selectById(1L);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(Usuario user:lista) {
			System.out.println("Nome: "+user.getNome()+" | Email: "+user.getEmail());
		}
		
		try {
			dao.update(julio);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			lista = dao.select();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(Usuario user:lista) {
			System.out.println("Nome: "+user.getNome()+" | Email: "+user.getEmail());
		}
		
		try {
			dao.delete(1L);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			lista = dao.select();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("--------------------------------");
		for(Usuario user:lista) {
			System.out.println("Nome: "+user.getNome()+" | Email: "+user.getEmail());
		}
		
	}
}
